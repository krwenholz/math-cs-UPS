jQuery(function($) {
	$("input[name='_semdate']").datepicker({ dateFormat: 'Y-m-d' });
});