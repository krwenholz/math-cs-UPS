<footer>
	<p>&copy;2012 University of Puget Sound</p>
	<p>Mathematics &amp; Computer Science</p>
	<nav role="navigation">
		<?php bones_footer_links(); ?>
	</nav>
</footer>
		
<!-- all js scripts are loaded in library/bones.php -->
<?php wp_footer(); ?>

</body>
</html> <!-- end page. what a ride! -->